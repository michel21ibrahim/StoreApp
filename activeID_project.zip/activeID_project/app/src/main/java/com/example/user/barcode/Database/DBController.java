package com.example.user.barcode.Database;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by Michel ibrahim on 14-Mar-20.
 */

public class DBController extends SQLiteOpenHelper {
    private static final String LOGCAT = null;

    public DBController(Context applicationcontext) {
        super(applicationcontext, "Retail.db", null, 1);  // creating a Database with name Retail.db
        Log.d(LOGCAT, "Created");
    }

    @Override
    public void onCreate(SQLiteDatabase database) {
        String query;
        query = "CREATE TABLE IF NOT EXISTS items ( Id INTEGER PRIMARY KEY, Barcode TEXT,Expected_Quantity TEXT)";
        database.execSQL(query);
    }


    @Override
    public void onUpgrade(SQLiteDatabase database, int version_old, int current_version) {
        String query;
        query = "DROP TABLE IF EXISTS items";
        database.execSQL(query);
        onCreate(database);
    }



    public Integer GetExpectedCount(){
        int count = 0;
        String selectQuery="SELECT SUM(Expected_Quantity) FROM items ";
        SQLiteDatabase database = this.getWritableDatabase();
        Cursor cursor = database.rawQuery(selectQuery, null);
        cursor.moveToFirst();

        count = cursor.getInt(0);
        return count;
    }


    public String GetBarcode(String item){
        String Barcode;
        String selectQuery="SELECT Count(*) FROM items where Barcode='"+ item +"'";
        SQLiteDatabase database = this.getWritableDatabase();
        Cursor cursor = database.rawQuery(selectQuery, null);
        cursor.moveToFirst();
        Barcode=cursor.getString(0);
        return Barcode;
    }

    public String GetExpected(String item){
        String Expected;
        String selectQuery="SELECT Expected_Quantity FROM items where Barcode='"+ item +"'";
        SQLiteDatabase database = this.getWritableDatabase();
        Cursor cursor = database.rawQuery(selectQuery, null);
        cursor.moveToFirst();
        Expected=cursor.getString(0);
        return Expected;
    }

    public ArrayList<HashMap<String, String>> getAllItems() {
        ArrayList<HashMap<String, String>> proList;
        proList = new ArrayList<HashMap<String, String>>();
        String selectQuery = "SELECT  * FROM items";
        SQLiteDatabase database = this.getWritableDatabase();
        Cursor cursor = database.rawQuery(selectQuery, null);
        if (cursor.moveToFirst()) {
            do {
                //Id, Company,Name,Price
                HashMap<String, String> map = new HashMap<String, String>();
                map.put("Barcode", cursor.getString(1));
                map.put("Expected_Quantity", cursor.getString(2));
                proList.add(map);
            } while (cursor.moveToNext());
        }

        return proList;
    }



    public Integer GetSumOfQuantityNotFound(String list){
        int count = 0;
        String selectQuery="SELECT SUM(Expected_Quantity) FROM items where Barcode NOT IN ("+list+")";
        SQLiteDatabase database = this.getWritableDatabase();
        Cursor cursor = database.rawQuery(selectQuery, null);
        cursor.moveToFirst();

        count = cursor.getInt(0);
        return count;
    }



}

