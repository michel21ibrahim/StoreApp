package com.example.user.barcode;

import android.Manifest;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Environment;
import android.provider.OpenableColumns;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;


import com.example.user.barcode.Database.DBController;

import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;

import java.io.File;

import java.io.FileReader;

import java.io.IOException;

public class ImportingData extends AppCompatActivity {
    DBController controller = new DBController(this);
    Button btnimport;

    private static final int REQUEST_CODE = 0;
    private boolean IsDone = false ,  check=false;;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_importingdata);

        btnimport = (Button) findViewById(R.id.btnimport);

        btnimport.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                checkPermission(Manifest.permission.READ_EXTERNAL_STORAGE ,REQUEST_CODE);
                if (check== true) {
                    showFileChooser();
                }

            }
        });

    }



    public void showFileChooser() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        // Update with mime types
        intent.setType("*/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.putExtra(Intent.EXTRA_LOCAL_ONLY, true);
        startActivityForResult(intent, REQUEST_CODE);
    }



    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        // If the user doesn't pick a file just return
        if (requestCode != REQUEST_CODE || resultCode != RESULT_OK) {
            return;
        }



            // Import the file
            importFile(data.getData());

            if (IsDone == true ) {
                Intent intent=new Intent(ImportingData.this, Inventory.class);
                startActivity(intent);
            }




    }

     public void importFile(Uri uri)   {
        String fileName = getFileName(uri);
        readFile(fileName);
    }

    /**
     * Obtains the file name for a URI using content resolvers. Taken from the following link
     *
     * @param uri a uri to query
     * @return the file name with no path
     * @throws IllegalArgumentException if the query is null, empty, or the column doesn't exist
     */
    private String getFileName(Uri uri) throws IllegalArgumentException {
        // Obtain a cursor with information regarding this uri
        Cursor cursor = getContentResolver().query(uri, null, null, null, null);

        if (cursor.getCount() <= 0) {
            cursor.close();
            throw new IllegalArgumentException("Can't obtain file name, cursor is empty");
        }

        cursor.moveToFirst();

        String fileName = cursor.getString(cursor.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME));

        cursor.close();

        return fileName;
    }

    public void readFile(String fileName){
        File textFile = new File(Environment.getExternalStorageDirectory(),"My Documents/"+fileName);
        controller = new DBController(getApplicationContext());
        SQLiteDatabase db = controller.getWritableDatabase();
            if (textFile.exists() && isExternalStorageReadble() ) {
                try {
                    CSVReader reader = new CSVReaderBuilder(new FileReader(textFile)).withSkipLines(1).build();
                    String tableName = "items";
                    db.execSQL("delete  from " + tableName);
                    String[] nextLine;
                    ContentValues contentValues = new ContentValues();
                    db.beginTransaction();

                    while ((nextLine = reader.readNext()) != null) {
                        // nextLine[] is an array of values from the line
                        String Barcode = nextLine[0].toString();
                        String Expected_Quantity = nextLine[1].toString();
                        contentValues.put("Barcode", Barcode);
                        contentValues.put("Expected_Quantity", Expected_Quantity);
                        db.insert(tableName, null, contentValues);
                    }

                    db.setTransactionSuccessful();
                    db.endTransaction();
                    IsDone=true;
                } catch (IOException e) {
                    if (db.inTransaction())
                        db.endTransaction();
                    IsDone=true;
                }

            }else{
                if (db.inTransaction())
                    db.endTransaction();
                Toast.makeText(getApplicationContext(),"Only CSV FILES AlLOWED ! ",Toast.LENGTH_LONG).show();
                IsDone=false;
            }


    }

    private boolean isExternalStorageReadble(){
        if (Environment.MEDIA_MOUNTED.equals(Environment.getExternalStorageState()) || Environment.MEDIA_MOUNTED_READ_ONLY.equals((Environment.getExternalStorageState()))){
            return  true   ;
        } else {
            return  false   ;
        }

    }

    public boolean checkPermission(String permission, int requestCode){


    // Checking if permission is not granted
        if (ContextCompat.checkSelfPermission(ImportingData.this,  permission) == PackageManager.PERMISSION_DENIED) {
            ActivityCompat
                    .requestPermissions(
                            ImportingData.this,
                            new String[] {  Manifest.permission.READ_EXTERNAL_STORAGE },  requestCode);
            check=true;
        }else {
            check=true;
        }

        return check;
    }

}

