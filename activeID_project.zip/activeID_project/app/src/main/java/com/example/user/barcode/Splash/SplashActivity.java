package com.example.user.barcode.Splash;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import com.example.user.barcode.ImportingData;
import com.example.user.barcode.R;

/**
 * Created by Michel ibrahim on 14-Mar-20.
 */

public class SplashActivity extends Activity {

    Handler handler;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.splash_screen);

        handler=new Handler();

        //Post Delayed : method will delay the time for 3 seconds. After the delay the main activity will be launched.

        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent=new Intent(SplashActivity.this, ImportingData.class);
                startActivity(intent);
                finish();
            }
        },3000);

    }
}
