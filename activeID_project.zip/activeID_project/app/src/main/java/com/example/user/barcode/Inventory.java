package com.example.user.barcode;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Environment;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.example.user.barcode.Database.DBController;
import com.example.user.barcode.zxing.CaptureActivity;
import com.opencsv.CSVWriter;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class Inventory extends AppCompatActivity {

    DBController controller = new DBController(this);
    static Integer Total = 0;
    static Integer Expected = 0;
    static Integer Added = 0;
    static Integer Found = 0;
    Integer ResultF = 0;
    Integer ResultM = 0;
    Integer ResultA = 0;
    Integer ResultE = 0;
    HashMap<String, List<Integer>> items = new HashMap<String, List<Integer>>();
    HashMap<String, String> items1 = new HashMap<String, String>();
    HashMap<String, List<Integer>> itemNotInDB = new HashMap<String, List<Integer>>();
    private static final int REQUEST_CODE = 0;
    private boolean check=false;;
    TextView txtTotalCount, txtExpectedCount, txtMissingCount, txtAddedCount, txtFoundCount;
    FloatingActionButton fab, reset, submit, scanner;
    String CheckBarcode;
    String GetExpected;
    int LAUNCH_SECOND_ACTIVITY = 1;
    boolean isFABOpen = false;
    ArrayList<HashMap<String, String>> myList;
    String Barcode, Expected_Quantity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        txtTotalCount = (TextView) findViewById(R.id.txtTotalCount);
        txtExpectedCount = (TextView) findViewById(R.id.txtExpectedCount);
        txtMissingCount = (TextView) findViewById(R.id.txtMissingCount);
        txtAddedCount = (TextView) findViewById(R.id.txtAddedCount);
        txtFoundCount = (TextView) findViewById(R.id.txtFoundCount);
        scanner = (FloatingActionButton) findViewById(R.id.scanner);
        fab = (FloatingActionButton) findViewById(R.id.fab);
        reset = (FloatingActionButton) findViewById(R.id.reset);
        submit = (FloatingActionButton) findViewById(R.id.submit);


        Expected = controller.GetExpectedCount();
        txtExpectedCount.setText(String.valueOf(Expected));
        txtTotalCount.setText(String.valueOf(Found + Added));


        scanner.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                checkPermission(Manifest.permission.CAMERA ,REQUEST_CODE);
                if (check == true) {
                    myList = controller.getAllItems();
                    for (int i = 0; i < myList.size(); i++) {
                        Barcode = myList.get(i).get("Barcode");
                        Expected_Quantity = myList.get(i).get("Expected_Quantity");
                        items1.put(Barcode, Expected_Quantity);
                    }
                    Intent i = new Intent(Inventory.this, CaptureActivity.class);
                    startActivityForResult(i, LAUNCH_SECOND_ACTIVITY);
                }
            }
        });

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!isFABOpen) {
                    showFABMenu();
                } else {
                    closeFABMenu();
                }
            }
        });
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == LAUNCH_SECOND_ACTIVITY) {
            if (resultCode == Activity.RESULT_OK) {
                GetTheSummationOfItemsExsistingInDB(data);
                GettheSummationOfMissingItemsExistingInDB();
            }
        }

    }

    private void GetTheSummationOfItemsExsistingInDB(Intent data) {


        // retireve the barcode name from the barcode Scanner
        String result = data.getStringExtra("result");

        CheckBarcode = controller.GetBarcode(result);
        if ("1".equals(CheckBarcode)) {

            String keyToBeChecked = result;
            GetExpected = controller.GetExpected(result);
            ResultE = Integer.parseInt(GetExpected);

            // Get the iterator over the HashMap
            Iterator<String> iterator = items1.keySet().iterator();

            // flag to store result
            boolean isKeyPresent = false;
            // Iterate over the HashMap
            while (iterator.hasNext()) {
                // Get the entry at this iteration
                String entry = iterator.next();
                // Check if this key is the required key
                if (entry.equals(keyToBeChecked)) {
                    isKeyPresent = true;
                }
            }
            // check if barcode exist in the list of keys
            if (isKeyPresent == true) {
                //check if the size of the list of items is not = 0
                if (items.size() != 0) {
                    String BarcodeToBeChecked = result;
                    // Get the iterator over the HashMap
                    Iterator<Map.Entry<String, List<Integer>>> iterators = items.entrySet().iterator();
                    // flag to store result
                    boolean isKeyPresents = false;
                    // Iterate over the HashMap
                    while (iterators.hasNext()) {
                        // Get the entry at this iteration
                        Map.Entry<String, List<Integer>> entries = iterators.next();
                        // Check if this key is the required key
                        if (entries.getKey().equals(BarcodeToBeChecked)) {
                            isKeyPresents = true;
                        }
                    }
                    if (isKeyPresents == true) {
                        System.out.println("test barcode before change: " + items.get(BarcodeToBeChecked));
                        ResultF = items.get(BarcodeToBeChecked).get(1) + 1;
                        ResultM = items.get(BarcodeToBeChecked).get(2);
                        ResultA = items.get(BarcodeToBeChecked).get(3);
                        if (ResultF == ResultE) {
                            ResultM = 0;
                            ResultA = 0;
                        } else if (ResultF > ResultE) {
                            ResultA = ResultF - ResultE;
                            ResultM = 0;
                            Added = Integer.parseInt(String.valueOf(txtAddedCount.getText()));
                            txtAddedCount.setText(String.valueOf(Added + 1));

                        } else if (ResultF < ResultE) {
                            ResultM = ResultE - ResultF;
                            ResultA = 0;

                        }
                        Integer[] valuesT = {ResultE, ResultF, ResultM, ResultA};
                        items.put(BarcodeToBeChecked, Arrays.asList(valuesT));
                        Found = Integer.parseInt(String.valueOf(txtFoundCount.getText()));
                        txtFoundCount.setText(String.valueOf(Found + 1));
                        System.out.println("test barcode after change: " + items.get(BarcodeToBeChecked));
                    } else {
                        //add if barcode not exist in items but exist in DB
                        ResultF = 1;
                        ResultM = ResultE - ResultF;
                        ResultA = 0;
                        Integer[] valuesT = {ResultE, ResultF, ResultM, ResultA};
                        items.put(result, Arrays.asList(valuesT));
                        Found = Integer.parseInt(String.valueOf(txtFoundCount.getText()));
                        txtFoundCount.setText(String.valueOf(Found + 1));
                    }
                    //hayde taba3 size != 0
                } else {
                    //add on the list for the first time the list is empty
                    ResultF = 1;
                    ResultM = ResultE - ResultF;
                    ResultA = 0;
                    Integer[] valuesT = {ResultE, ResultF, ResultM, ResultA};
                    items.put(result, Arrays.asList(valuesT));
                    System.out.println("test of adding items : " + items);
                    Found = Integer.parseInt(String.valueOf(txtFoundCount.getText()));
                    txtFoundCount.setText(String.valueOf(Found + 1));
                }

            }
            //add the item in the list of itemNotInDB that not exist in DB
        } else {
            AddItemsNotExistInDB(result);
            System.out.println("items not exist :  " + itemNotInDB);
        }

        Integer add = Integer.parseInt(String.valueOf(txtAddedCount.getText()));
        Integer found = Integer.parseInt(String.valueOf(txtFoundCount.getText()));
        Total = add + found;
        txtTotalCount.setText(String.valueOf(Total));
    }

    // show the float buttons
    private void showFABMenu() {
        isFABOpen = true;
        fab.setImageDrawable(ContextCompat.getDrawable(getApplicationContext(), R.drawable.baseline_close_18dp));
        reset.animate().translationY(-getResources().getDimension(R.dimen.standard_60));
        submit.animate().translationY(-getResources().getDimension(R.dimen.standard_120));

        // reset the activity
        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //  reload();
                items.clear();
                itemNotInDB.clear();
                Added = 0;
                Found = 0;
                finish();
                startActivity(getIntent());

            }
        });

        //exports data ....
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    ExportingData();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                closeFABMenu();
                Toast.makeText(getApplicationContext(),"File Exported",Toast.LENGTH_LONG).show();
            }
        });

    }

    // disappear the float buttons
    private void closeFABMenu() {
        isFABOpen = false;
        fab.setImageDrawable(ContextCompat.getDrawable(getApplicationContext(), R.drawable.baseline_view_headline_18dp));
        reset.animate().translationY(0);
        submit.animate().translationY(0);


    }

    // Add Items in a list  itemNotInDB That Not Exist In DB
    private void AddItemsNotExistInDB(String result) {
        System.out.println("item " + result + "not exist ");
        if (itemNotInDB.size() != 0) {
            String BarcodeToBeChecked = result;
            // Get the iterator over the HashMap
            Iterator<Map.Entry<String, List<Integer>>> iterators = itemNotInDB.entrySet().iterator();
            // flag to store result
            boolean isKeyExist = false;
            // Iterate over the HashMap
            while (iterators.hasNext()) {
                // Get the entry at this iteration
                Map.Entry<String, List<Integer>> entries = iterators.next();
                // Check if this key is the required key
                if (entries.getKey().equals(BarcodeToBeChecked)) {
                    isKeyExist = true;
                }
            }
            if (isKeyExist == true) {
                ResultE = itemNotInDB.get(BarcodeToBeChecked).get(0);
                ResultF = itemNotInDB.get(BarcodeToBeChecked).get(1);
                ResultM = itemNotInDB.get(BarcodeToBeChecked).get(2);
                ResultA = itemNotInDB.get(BarcodeToBeChecked).get(3) +1;
                Integer[] values = {ResultE, ResultF, ResultM, ResultA};
                itemNotInDB.put(BarcodeToBeChecked, Arrays.asList(values));
                Added = Integer.parseInt(String.valueOf(txtAddedCount.getText()));
                txtAddedCount.setText(String.valueOf(Added + 1));
            }else {
                //add if barcode not exist in the list of itemNotInDB
                ResultE = 0;
                ResultF = 0;
                ResultM = 0;
                ResultA = 1;
                Integer[] values = {ResultE, ResultF, ResultM, ResultA};
                itemNotInDB.put(result, Arrays.asList(values));
                Added = Integer.parseInt(String.valueOf(txtAddedCount.getText()));
                txtAddedCount.setText(String.valueOf(Added + 1));
            }
            // add the barcode first time if the list of itemNotInDB is empty
        } else {
            ResultE = 0;
            ResultF = 0;
            ResultM = 0;
            ResultA = 1;
            Integer[] values = {ResultE, ResultF, ResultM, ResultA};
            itemNotInDB.put(result, Arrays.asList(values));
            Added = Integer.parseInt(String.valueOf(txtAddedCount.getText()));
            txtAddedCount.setText(String.valueOf(Added + 1));
        }
    }

    //Get the Summation Of Missing Items Existing In the DB
    private void GettheSummationOfMissingItemsExistingInDB(){
        String list = "";
        Integer MissingCountFromDB=0;
        Integer GrandTotal=0;
        Integer MissingCountOfItems=0;
        // Get the values of each keys
        for (Map.Entry<String, List<Integer>> entry : items.entrySet()) {
            MissingCountOfItems  += entry.getValue().get(2);
        }
        if (items.size()==1){
            list = Arrays.toString(items.keySet().toArray()).replace("[", "'").trim().replace("]", "'").trim().replaceAll("\\s+","");
        }else {
            list = Arrays.toString(items.keySet().toArray()).trim().replace("[", "'").trim().replace(",", "','").trim()
                    .replace("]", "'").trim().replaceAll("\\s+","");
        }

        MissingCountFromDB=controller.GetSumOfQuantityNotFound(list);
        GrandTotal = MissingCountFromDB + MissingCountOfItems ;

        txtMissingCount.setText(String.valueOf(GrandTotal));

    }


    private void ExportingData() throws IOException {


        if ((itemNotInDB.size() > 0) || (items.size() > 0)) {
            String directoryName = Environment.getExternalStorageDirectory().getAbsolutePath() + "/My Documents/exports";
            String fileName = "ExportingData.csv";
            String filePath = directoryName + File.separator + fileName;

            FileWriter mFileWriter;
            File f = new File(filePath);
            CSVWriter writer;


            File directory = new File(directoryName);
            if (!directory.exists()) {
                directory.mkdir();
            }

            // File exist
            if (f.exists() && !f.isDirectory()) {
                mFileWriter = new FileWriter(filePath);
                writer = new CSVWriter(mFileWriter);
            } else {
                writer = new CSVWriter(new FileWriter(filePath));
            }

            List<Integer> myArrList = new ArrayList<>();
            String Barcode = "";
            Integer ExpectedValues = 0;
            Integer FoundValues = 0;
            Integer MissingValues =0;
            Integer AddedValues = 0;

            String[] header = {"Barcode", "Expected Quantity", "Found Quantity", "Missing Quantity", "Added Quantity"};
            writer.writeNext(header);
            String[] line = new String[header.length];

            if (itemNotInDB.size() > 0) {

                Iterator keys = itemNotInDB.keySet().iterator();

                while (keys.hasNext()) {
                    String key = (String) keys.next();
                    myArrList = itemNotInDB.get(key);

                    Barcode = key;
                    ExpectedValues = myArrList.get(0);
                    FoundValues = myArrList.get(1);
                    MissingValues = myArrList.get(2);
                    AddedValues = myArrList.get(3);
                    line = new String[]{Barcode, ExpectedValues.toString(), FoundValues.toString(), MissingValues.toString(), AddedValues.toString()};
                    //System.out.println(line);
                    writer.writeNext(line);
                }

            }
            if (items.size() > 0) {

                Iterator keys = items.keySet().iterator();

                while (keys.hasNext()) {
                    String key = (String) keys.next();
                    myArrList = items.get(key);

                    Barcode = key;
                    ExpectedValues = myArrList.get(0);
                    FoundValues = myArrList.get(1);
                    MissingValues = myArrList.get(2);
                    AddedValues = myArrList.get(3);

                    if (FoundValues > ExpectedValues){
                        FoundValues = ExpectedValues;
                    }


                    line = new String[]{Barcode, ExpectedValues.toString(), FoundValues.toString(), MissingValues.toString(), AddedValues.toString()};
                    writer.writeNext(line);
                }

            }


            writer.close();

        }else{
            Toast.makeText(getApplicationContext(),"No Data read To export it ",Toast.LENGTH_LONG).show();

        }

    }

    public boolean checkPermission(String permission, int requestCode){


        // Checking if permission is not granted
        if (ContextCompat.checkSelfPermission(Inventory.this,  permission) == PackageManager.PERMISSION_DENIED) {
            ActivityCompat
                    .requestPermissions(
                            Inventory.this,
                            new String[] {  Manifest.permission.CAMERA },  requestCode);
            check=true;
        }else {
            check=true;
        }

        return check;
    }
}